package com.evolutionstudio.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    
    private static final int SPLASH_DURATION = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logo = findViewById(R.id.logo);
        TextView appName = findViewById(R.id.app_name_text);
        View poweredBy = findViewById(R.id.powered_by_container);

        // 1. Logo Animation: Scale + Fade In
        AnimationSet logoAnim = new AnimationSet(true);
        ScaleAnimation scale = new ScaleAnimation(0.7f, 1.0f, 0.7f, 1.0f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        AlphaAnimation fadeIn = new AlphaAnimation(0, 1);
        logoAnim.addAnimation(scale);
        logoAnim.addAnimation(fadeIn);
        logoAnim.setDuration(1200);
        logoAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        logo.startAnimation(logoAnim);

        // 2. App Name Animation: Slide Up + Fade In (Delayed)
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            appName.setAlpha(1.0f);
            AnimationSet textAnim = new AnimationSet(true);
            TranslateAnimation slideUp = new TranslateAnimation(0, 0, 50, 0);
            AlphaAnimation textFadeIn = new AlphaAnimation(0, 1);
            textAnim.addAnimation(slideUp);
            textAnim.addAnimation(textFadeIn);
            textAnim.setDuration(800);
            appName.startAnimation(textAnim);
        }, 600);

        // 3. Powered By Animation: Fade In (Delayed)
        poweredBy.setAlpha(0);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            poweredBy.animate().alpha(1.0f).setDuration(1000).start();
        }, 1200);

        // Transition to MainActivity
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, SPLASH_DURATION);
    }
}
