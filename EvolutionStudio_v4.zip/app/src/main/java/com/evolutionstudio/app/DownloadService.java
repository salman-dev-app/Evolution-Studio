package com.evolutionstudio.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class DownloadService extends Service {
    private static final String CHANNEL_ID = "download_channel";
    private static final String ACTION_CANCEL = "com.evolutionstudio.app.ACTION_CANCEL";
    private static final int NOTIFICATION_ID_FOREGROUND = 1001;
    private NotificationManager notificationManager;
    private final Map<Integer, Boolean> cancelledDownloads = new HashMap<>();

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_CANCEL.equals(intent.getAction())) {
            int notificationId = intent.getIntExtra("notificationId", -1);
            if (notificationId != -1) {
                cancelledDownloads.put(notificationId, true);
                notificationManager.cancel(notificationId);
            }
            return START_NOT_STICKY;
        }

        String url = intent.getStringExtra("url");
        String fileName = intent.getStringExtra("fileName");
        String userAgent = intent.getStringExtra("userAgent");
        String cookies = intent.getStringExtra("cookies");
        int notificationId = (int) System.currentTimeMillis();

        NotificationCompat.Builder foregroundBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Preparing Download")
                .setPriority(NotificationCompat.PRIORITY_LOW);
        startForeground(NOTIFICATION_ID_FOREGROUND, foregroundBuilder.build());

        new Thread(() -> startDownload(url, fileName, userAgent, cookies, notificationId)).start();

        return START_NOT_STICKY;
    }

    private void startDownload(String urlStr, String fileName, String userAgent, String cookies, int notificationId) {
        cancelledDownloads.put(notificationId, false);

        Intent cancelIntent = new Intent(this, DownloadService.class);
        cancelIntent.setAction(ACTION_CANCEL);
        cancelIntent.putExtra("notificationId", notificationId);
        PendingIntent pendingCancel = PendingIntent.getService(this, notificationId, cancelIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Downloading " + fileName)
                .setContentText("0% downloaded")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", pendingCancel)
                .setProgress(100, 0, false);

        notificationManager.notify(notificationId, builder.build());

        Uri fileUri = null;
        try {
            URL url = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            if (userAgent != null) connection.setRequestProperty("User-Agent", userAgent);
            if (cookies != null) connection.setRequestProperty("Cookie", cookies);
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(15000);
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new Exception("Server returned code: " + connection.getResponseCode());
            }

            int fileLength = connection.getContentLength();
            InputStream input = new BufferedInputStream(connection.getInputStream());
            
            OutputStream output;
            String extension = MimeTypeMap.getFileExtensionFromUrl(urlStr);
            if (extension == null || extension.isEmpty()) {
                extension = MimeTypeMap.getFileExtensionFromUrl(fileName);
            }
            String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            if (mimeType == null) mimeType = "application/octet-stream";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                
                fileUri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (fileUri == null) throw new Exception("Failed to create MediaStore entry");
                output = getContentResolver().openOutputStream(fileUri);
            } else {
                File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloadDir.exists()) downloadDir.mkdirs();
                File file = new File(downloadDir, fileName);
                output = new FileOutputStream(file);
                fileUri = Uri.fromFile(file);
            }

            if (output == null) throw new Exception("Failed to open output stream");

            byte[] data = new byte[8192];
            long total = 0;
            int count;
            int lastProgress = -1;

            while ((count = input.read(data)) != -1) {
                if (Boolean.TRUE.equals(cancelledDownloads.get(notificationId))) {
                    output.close();
                    input.close();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && fileUri != null) {
                        getContentResolver().delete(fileUri, null, null);
                    } else if (fileUri != null) {
                        new File(fileUri.getPath()).delete();
                    }
                    return;
                }

                total += count;
                if (fileLength > 0) {
                    int progress = (int) (total * 100 / fileLength);
                    if (progress > lastProgress) {
                        builder.setProgress(100, progress, false);
                        builder.setContentText(progress + "% downloaded");
                        notificationManager.notify(notificationId, builder.build());
                        lastProgress = progress;
                    }
                }
                output.write(data, 0, count);
            }

            output.flush();
            output.close();
            input.close();

            // Success notification
            NotificationCompat.Builder successBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Download Complete")
                    .setContentText(fileName)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .setOngoing(false);

            Intent openIntent = new Intent(Intent.ACTION_VIEW);
            openIntent.setDataAndType(fileUri, mimeType);
            openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, openIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            successBuilder.setContentIntent(pendingIntent);
            
            notificationManager.notify(notificationId, successBuilder.build());

        } catch (Exception e) {
            NotificationCompat.Builder errorBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("Download Failed")
                    .setContentText(e.getMessage() != null ? e.getMessage() : "Unknown error")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setOngoing(false);
            notificationManager.notify(notificationId, errorBuilder.build());
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && fileUri != null) {
                getContentResolver().delete(fileUri, null, null);
            }
        } finally {
            cancelledDownloads.remove(notificationId);
            stopForeground(true);
            stopSelf();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Downloads",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Download progress notifications");
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
